// script.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import {
  getFirestore,
  collection,
  addDoc,
  serverTimestamp,
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

// Your Firebase config (fill in your keys)
const firebaseConfig = {
  apiKey: "", // add your API key
  authDomain: "replitdatabase-3e145.firebaseapp.com",
  projectId: "replitdatabase-3e145",
  storageBucket: "replitdatabase-3e145.appspot.com",
  messagingSenderId: "673938519491",
  appId: "1:673938519491:web:8d0f447b331c078f2bb976",
};

// Initialize Firebase and Firestore
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("contactForm");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    // Get form data
    const fullname = form.fullname.value.trim();
    const phone = form.phone.value.trim();
    const email = form.email.value.trim();

    if (!fullname || !email) {
      alert("Please fill out the required fields.");
      return;
    }

    try {
      // Save data to Firestore collection "contacts"
      await addDoc(collection(db, "contacts"), {
        fullname,
        phone,
        email,
        timestamp: serverTimestamp(),
      });

      alert("Contact info saved successfully!");
      form.reset();
    } catch (error) {
      console.error("Error saving contact info:", error);
      alert("Failed to save data. Please try again.");
    }
  });
});
